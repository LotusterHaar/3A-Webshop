<?php
function isLoggedin()
{
    if (isset($_SESSION['user']) && $_SESSION['user'] !== '')
    {
        return true;
    } else {
        false;
    }
}

function hasError()
{
    if (isset($_SESSION['error']) && $_SESSION['error'] !== '')
    {
        return true;
    } else {
        false;
    }
}

function checkLogin($username,$password)
{

}

function avtarUrl()
{
	
}

function logout()
{
    session_destroy();
    session_unset();
}
