<?php
if ( isset( $_COOKIE[session_name()] ) )
setcookie( session_name(), “”, time()-3600, “/” );

//clear session from globals
$_SESSION = array();
//clear session from disk
session_destroy();

if ($_SERVER['HTTP_REFERER']<>0)
header ("Location: "+$_SERVER['HTTP_REFERER']);
else
header ("Location: /");

?>

