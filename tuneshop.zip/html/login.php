<?php
session_start();
require_once('../protectedfunctions/dbfunctions.php');
require_once('../protectedfunctions/generalfunctions.php');
unset($_SESSION['error']); # reset error message

error_log("---", 0);

error_log("---", 0);

#$_SESSION['avatar']="janwil.jpg";
#$_SESSION['user'] = "janwil";

#Browser zou dit al checken maar voor de volledigheid toch deze extra check
if (isset($_REQUEST['username']) && !empty($_REQUEST['username']))
	$username=$_REQUEST['username'];
else
	$_SESSION['error']="Geen username opgegeven";

if (isset($_REQUEST['password']) && !empty($_REQUEST['password']))
	$password=$_REQUEST['password'];
else
	$_SESSION['error']="Geen wachtwoord opgegeven";

if (isset($_SESSION['error']) && !empty($_SESSION['error']))
error_log("Error: ".$_SESSION['error'], 0);

$DB = db_con();
$stmt = $DB->prepare("SELECT * FROM user WHERE username = ?");
$stmt->execute($username);
$user = $stmt->fetch();

error_log("DB: ".$DB, 0);
error_log("user: ".$user, 0);

if (isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER']))
header ("Location: ".$_SERVER['HTTP_REFERER']);
else
header ("Location: /");

exit;
?>
