<?php
include 'includes/header.html';
require_once('../protectedfunctions/dbfunctions.php');

#include 'includes/footer.html';
?>
